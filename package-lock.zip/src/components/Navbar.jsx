import React from 'react'
import avatar from '../img/addAvatar.png'
const Navbar = () => {
  return (
    <div className='navbar'>
      <span className='navbar'>Lama chat</span>
      <div className='user'>
        <img src={avatar} alt="" />
        <span>John</span>
        <button>logout</button>
      </div>
      
    </div>
  )
}

export default Navbar
