import React from 'react'
import avatar from '../img/addAvatar.png'

const Chats = () => {
  return (
    <div className='Chats'>
      <div className="userChat">
        <img src={avatar} alt="" />
        <div className="userChatInfo">
          <span>Jane</span>
          <p>Hello</p>
        </div>
      </div>
      <div className="userChat">
        <img src={avatar} alt="" />
        <div className="userChatInfo">
          <span>Jane</span>
          <p>Hello</p>
        </div>
      </div>
      <div className="userChat">
        <img src={avatar} alt="" />
        <div className="userChatInfo">
          <span>Jane</span>
          <p>Hello</p>
        </div>
      </div>

    </div>
  )
}

export default Chats
