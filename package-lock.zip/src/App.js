import Register from "./pages/Register"
// import Login from "./pages/Login"
import Home from "./pages/Home"

import "./Style.scss"
function App() {
  return (
   
<div> 
  <Register />
</div>   
  );
}

export default App;
